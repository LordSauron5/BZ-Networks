<?php 



?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>


<?php include('includes/footer.php') ?>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>