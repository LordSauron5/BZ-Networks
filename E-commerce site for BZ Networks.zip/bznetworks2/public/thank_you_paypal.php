<!-- Configuration-->
<?php require_once("../resources/config.php") ?>
<!-- header -->
<?php include('includes/header.php') ?>
    <!-- Page Content -->
<div class="container">


<!-- /.row --> 
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="POST" target = "_blank">
    <div class="container">
    <!-- /.row --> 

    <div class="row">
        <div class="col s12 m7">
        <div class="card large">
            <div class="card-image">
            <img src="./assets/white-and-blue-cables-2881229.jpg">
        </div>
        <div class="card-content">
            <span class="card-title">Order successful! Please proceed below to make your payment at PayPal!</span>
            </div>
            <div class="card-action">
            <a href="logout.php">I'm Done, log me out please</a>
            <button class = "btn waves-effect waves-light" type="submit" name = "paypal" value "paypal" >Proceed to PayPal<i class="material-icons right">attach_money</i></button>
            </div>
        </div>
        </div>
    </div>
</div>
  <input type="hidden" name="cmd" value="_cart">
  <input type="hidden" name="business" value="tyronaricum2@gmail.com">
  <input type="hidden" name="currency_code" value="USD">
  <input type="hidden" name="upload" value="1">
    <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
     
          </tr>
        </thead>
        <tbody>
        <?php cart(); ?>
        </tbody>
    </table>
</form>
</div>

 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All scripts required -->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script type="text/javascript" src="js/materialize.js"></script>
    <script type="text/javascript" src="js/init.js"></script>
</body>
<?php include('includes/footer.php') ?>
</html>