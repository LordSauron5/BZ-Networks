<!-- Configuration-->
<?php require_once("../resources/config.php") ?>
<!-- header -->
<?php include('includes/header.php') ?>
    <!-- Page Content -->
<div class="container">


<!-- /.row --> 

    <div class="row">
        <div class="col s12 m7">
        <div class="card large">
            <div class="card-image">
            <img src="./assets/white-and-blue-cables-2881229.jpg">
        </div>
        <div class="card-content">
            <span class="card-title">Order successful! Thank You for your purchase!</span>
            <p>Keep the connection alive, browse through more products or contact us for a quote.</p>
            </div>
            <div class="card-action">
            <a href="logout.php">I'm Done, log me out please</a>
            <a href="index.php">Take me back home</a>
            </div>
        </div>
        </div>
    </div>
</div>

 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All scripts required -->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script type="text/javascript" src="js/materialize.js"></script>
    <script type="text/javascript" src="js/init.js"></script>
</body>
<?php include('includes/footer.php') ?>
</html>