<?php require_once("../../resources/config.php") ?>
<?php include(ACTION_BACK . "/header.php") ?>
<?php 

if(!isset($_SESSION['username'])){
    redirect("../../public");
}

?>
        <div id="page-wrapper">

            <div class="container-fluid">
                <!-- /.row -->

<?php 

if(($_SERVER['REQUEST_URI'] == "/bznetworks2/public/admin/") || ($_SERVER['REQUEST_URI'] == "/bznetworks2/public/admin/index.php")){
    include(ACTION_BACK . "/admin_content.php");
}

if (isset($_GET['orders'])) {
    include(ACTION_BACK . "/orders.php");
}

if (isset($_GET['services'])) {
    include(ACTION_BACK . "/services.php");
}

if (isset($_GET['add_service'])) {
    include(ACTION_BACK . "/add_service.php");
}

if (isset($_GET['products'])) {
    include(ACTION_BACK . "/products.php");
}

if (isset($_GET['add_product'])) {
    include(ACTION_BACK . "/add_product.php");
}

if (isset($_GET['users'])) {
    include(ACTION_BACK . "/users.php");
}

?>

            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php include(ACTION_BACK . "/footer.php") ?>
