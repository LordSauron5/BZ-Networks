(function($){
  $(function(){
    $('.sidenav').sidenav();
    
    $(document).ready(function(){
      $('.slider').slider();
    });
    $(document).ready(function() {
      $('input#phone').characterCounter();
    });
    $(document).ready(function(){
      $('select').formSelect();
    });
    $(document).ready(function(){
      $('.modal').modal();
    });
    $(document).ready(function(){
      $('.tooltipped').tooltip({
        enterDelay : 1000
      });
    });
  }); // end of document ready
})(jQuery); // end of jQuery name space

