<?php require_once("../resources/config.php") ?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>

 <!-- slideshow -->
 <?php include(ACTION_FRONT . DS . "slider.php") ?>

   <!-- Services cards -->

   <h2 class = "center blue-text text-darken-2">Solutions We Offer</h2><hr class = "blue-text">
   <div class="row">
    <div class="col s12 m6 l3">
      <div class="card medium hoverable">
        <div class="card-image">
          <img src="https://images.unsplash.com/photo-1592438710388-bf464c011df9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80">
          <span class="card-title">Office and Home</span>
        </div>
        <div class="card-content">
          <p>We provide all that you need to stay connected, wherever you are. For affordable office and home solutions give us a call.</p>
        </div>
      </div>
    </div>
    <div class="col s12 m6 l3">
    <div class="card medium hoverable">
        <div class="card-image">
          <img src="https://images.unsplash.com/photo-1566060475410-1159300f046f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=967&q=80">
          <span class="card-title">CCTV</span>
        </div>
        <div class="card-content">
          <p>Closed-circuit television (CCTV) and security solutions made possible. We work with trusted brands to provide the best quality surveillance to you</p>
        </div>
      </div>
    </div>
    <div class="col s12 m6 l3">
    <div class="card medium hoverable">
        <div class="card-image">
          <img src="https://images.unsplash.com/photo-1586772002130-b0f3daa6288b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80">
          <span class="card-title">Server Installations and Maintenance</span>
        </div>
        <div class="card-content">
          <p>Looking to install new servers? BZ Networks has you covered. We do all installations including cable runs. Guaranteed service delivery.</p>
        </div>
      </div>
    </div>
    <div class="col s12 m6 l3">
    <div class="card medium hoverable">
        <div class="card-image">
          <img src="https://images.unsplash.com/photo-1535016120720-40c646be5580?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60">
          <span class="card-title">Audio Visual Installations</span>
        </div>
        <div class="card-content">
          <p>We do more than just networking, BZ Networks uses all relevant technologies in the ICT industry to enhance your business or home environment.</p>
        </div>
      </div>
    </div>
  </div>  

<?php include('includes/footer.php') ?>

<!-- All scripts required -->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>