<?php 



?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>

<div class="stuff">
    <div class="container row about-header">
        <img class="about-logo " src="./assets/BZ_Logo.png" alt=" bzlogo">
        <div class="col s12 center about-title">
            <span class="blue-text text-darken-2">
                <h3>About Bz Networks</h3>
            </span>
            
            <span class="black-text"><hr class = "about-des">
                <p>BZ Networks is a sole propietorship business owned and managed by telecommunications specialist, Antonio Armino. BZ Networks provides clients with satisfied solutions, quality, performance, and effective execution strategies for all your networking needs. BZ Networks provides solutions in areas such as: telecommunications, network administration, wireless infrastructure and mobility, AV, and surveillance systems.</p>
                <p>The business is rapidly growing, with you "the client" being the catalyst for growth. Let us know, how we can help you!</p><hr class = "about-des">
            </span>
        </div>
    </div>
</div>

<div class="container">
<div class="card-panel blue darken-3"><span class="white-text text-darken-2"><h5>Why choose us?</h5></span></div>
<ul class="collection">
    <li class="collection-item avatar">
    <i class="material-icons circle orange">phone_in_talk</i>
      <span class="title">Excellent Service Delivery</span>
      <p>We try out best to reach our clients within 48 hours <br>
         Identifying what best suits your needs.
      </p>
      <a href="#!" class="secondary-content"><i class="material-icons">grade</i></a>
    </li>
    <li class="collection-item avatar">
      <i class="material-icons circle">face</i>
      <span class="title">Client's Best Interest Approach</span>
      <p>We only provide what you waant. <br>
         Why waste money on irrelevant technologies?
      </p>
      <a href="#!" class="secondary-content"><i class="material-icons">grade</i></a>
    </li>
    <li class="collection-item avatar">
      <i class="material-icons circle green">insert_chart</i>
      <span class="title">Trusted Brands</span>
      <p>Only internationally recognized and well trusted brands gel with us. <br>
         If we won't use it, best avoid it.
      </p>
      <a href="#!" class="secondary-content"><i class="material-icons">grade</i></a>
    </li>
    <li class="collection-item avatar">
      <i class="material-icons circle red">desktop_windows</i>
      <span class="title">Maintenance and Support</span>
      <p>Our clients are out number 1 priority <br>
         BZ Networks technicians are available for any maintenance and repairs.
      </p>
      <a href="#!" class="secondary-content"><i class="material-icons">grade</i></a>
    </li>
  </ul>
</div>

<div class="container">
<h4 class = "center blue-text text-darken-2">A word from our clients</h4><hr class = "blue-text">
    <div class="row">
        <div class="col s12 m4">
          <div class="card-panel blue darken-3">
          <h5 class = "center white-text text-darken-2">Client</h5>
            <span class="white-text">I am a very simple card. I am good at containing small bits of information.
            I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
            </span>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="card-panel blue darken-2">
          <h5 class = "center white-text text-darken-2">Client</h5>
            <span class="white-text">I am a very simple card. I am good at containing small bits of information.
            I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
            </span>
          </div>
        </div>

        <div class="col s12 m4">
          <div class="card-panel blue darken-1">
          <h5 class = "center white-text text-darken-2">Client</h5>
            <span class="white-text">I am a very simple card. I am good at containing small bits of information.
            I am convenient because I require little markup to use effectively. I am similar to what is called a panel in other frameworks.
            </span>
          </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php') ?>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>