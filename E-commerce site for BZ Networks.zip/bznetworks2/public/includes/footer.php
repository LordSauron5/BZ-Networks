<footer class="page-footer grey darken-4">
          <div class="container ">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Lets Get Connected</h5>
                <p class="grey-text text-lighten-4">Contact us for a quote today.</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Find us on:</h5>
                <ul>
                  <li><i class="fab fa-facebook"></i><a class="grey-text text-lighten-3" href="#!"> Facebook</a></li>
                  <li><i class="fab fa-instagram"></i><a class="grey-text text-lighten-3" href="#!"> Instagram</a></li>
                  <li><i class="fab fa-linkedin"></i><a class="grey-text text-lighten-3" href="#!"> LinkedIn</a></li>
                  <li><i class="far fa-envelope"></i><a class="grey-text text-lighten-3" href="#!"> Mail</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright grey darken-3" >
            <div class="container center">
            © <?php echo date("Y") ?> BZNETWORKS
            </div>
          </div>
        </footer>