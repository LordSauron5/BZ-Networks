<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./assets/BZ_Logo.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a5a1de190b.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/materialize.min.css" media="screen,projection">
    <link rel="stylesheet" href="css/style.css" media="screen,projection">
    <link rel="stylesheet" href="css/style2.css" media="screen,projection">
    <title>bznetworks</title>
</head>
<body>
<nav class="nav-extended grey darken-4 topnav">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">
        <div class="row">
            <div class="col s4 bz-logo">Logo</div>
            <div class="col s7 bz-title">BzNetworks</div>
        </div>
      </a>
      <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="index.php">Home</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="shop.php">Shop</a></li>
        <li><a href="about-us.php">About Us</a></li>
        <li><a href="request_quote.php">Request a Quote</a></li>
        <?php 
        echo isset($_SESSION['username']) ?
        '<li><a href="checkout.php">Checkout</a></li>'.
        '<li><a href="logout.php">Log Out</a></li>' : 
        '<li><a href="login.php">Register / Login</a></li>';
        ?>
      </ul>
    </div>
  </nav>

<ul class="sidenav grey lighten-2 " id="mobile-demo">
    <li><a href="index.php">Home</a></li>
    <li ><a href="services.php" >Services</a></li>
    <li><a href="shop.php">Shop</a></li>
    <li><a href="about-us.php">About Us</a></li>
    <li><a href="request_quote.php">Request a Quote</a></li>
    <?php 
        echo isset($_SESSION['username']) ?
        '<li><a href="checkout.php">Checkout</a></li>'.
        '<li><a href="logout.php">Log Out</a></li>' : 
        '<li><a href="login.php">Register / Login</a></li>';
    ?>
</ul>