<?php require_once("../resources/config.php") ?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>

<div class="stuff">
    <div class="container row about-header">
        <img class="about-logo " src="./assets/shopping-cart-hi.png" alt=" shopping">
        <div class="col s12 center about-title">
            <span class="blue-text text-darken-2">
                <h3>Just need to grab a few things?</h3>
            </span>
            
            <span class="black-text"><hr class = "about-des">
                <p>We do more than just provide solutions. Anything you need, we make possible. Have something in mind, lets get you back up and running with your networking needs</p>
                <p>Have a look through our product range, drop it in your cart, and keep the Data Flowing!</p>
            </span>
        </div>
    </div>
</div>

<div class="container">
  <h4 class = "left-align blue-text text-darken-2">Quick Shop</h4>
  <div class="row">
    <?php get_products_in_shop_page(); ?>
  </div>
</div>

<?php include('includes/footer.php') ?>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>