<?php require_once("../resources/config.php") ?>
<?php include('includes/header.php') ?>
<!DOCTYPE html>
<html lang="en">
 


<div class="section"></div>
  <main>
    <center>
      <img class="responsive-img" style="width: 250px;" src="./assets/BZNetworks.png" />
      <div class="section"></div>
      <h5 class="indigo-text">Please, enter your details below</h5>
      <h5 class="text-center red"><?php display_message(); ?></h5>
      <div class="section"></div>

      <div class="container">
        <div class="z-depth-1 grey lighten-4 row" style="display: inline-block; padding: 32px 48px 0px 48px; border: 1px solid #EEE;">

          <form class="col s12" method="post">
          <?php register_user(); ?>
            <div class='row'>
              <div class='col s12'>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
              <i class="material-icons prefix">account_circle</i>
                <input class='validate' type='text' name='username' id='username' />
                <label for='username'>Enter your username</label>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s6'>
              <i class="material-icons prefix">person</i>
                <input class='validate' type='text' name='fname' id='fname' />
                <label for='username'>First Name</label>
              </div>

              <div class='input-field col s6'>
              <i class="material-icons prefix">person</i>
                <input class='validate' type='text' name='lname' id='lname' />
                <label for='username'>Last Name</label>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
              <i class="material-icons prefix">mail</i>
                <input class='validate' type='email' name='email' id='email' />
                <label for='username'>Email address</label>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
              <i class="material-icons prefix">phone</i>
                <input class='validate' type='text' name='contact' id='contact' />
                <label for='username'>Phone number</label>
              </div>
            </div>

            <div class='row'>
              <div class='input-field col s12'>
              <i class="material-icons prefix">https</i>
                <input class='validate' type='password' name='password' id='password' />
                <label for='password'>Create password</label>
              </div>
            </div>

              <div class='row'>
              <div class='input-field col s12'>
              <i class="material-icons prefix">https</i>
                <input class='validate' type='password' name='password2' id='password2' />
                <label for='password'>Confirm password</label>
              </div>

            <div class="row">
                <div class="input-field col s12">
                  <i class="material-icons prefix">home</i>
                  <textarea id="home" name='home'  class="materialize-textarea validate"></textarea>
                  <label for="home">Full Address</label>
                </div>
            </div>

            <br />
            <center>
              <div class='row'>
                <button type='submit' name='submit' class='col s12 btn btn-large waves-effect indigo'>Create Account</button>
              </div>
            </center>
          </form>
        </div>
      </div>
    </center>

    <div class="section"></div>
    <div class="section"></div>
  </main>





</body>
<?php include('includes/footer.php') ?>
<!-- All scripts required -->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</html>