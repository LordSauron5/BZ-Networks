<?php require_once("../resources/config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>

<div class="row valign-wrapper service-header">
    <div class="col s7 center-align">
    <h3 class = "blue-text text-darken-2">How can we help you?</h3>
        <span class="black-text">
            BZ Networks offers a wide variety of solutions to suit your networking needs. We offer solutions in all the services below. Although we specialise in networking solutions, we try to cover all areas revolving around telecommunication services too. Don't see what you need? Get in touch with us, and we will make it possible.
        </span>
    </div>
    <div class="col s5 ">
        <img src="assets/blur-computer-connection-electronics-442150.jpg" alt="" class="circle responsive-img srv-logo"> <!-- notice the "circle" class -->
    </div>
</div><hr class= "divider-line">


<!-- Services -->
<div class="wash-background">
    <img src="./assets/BZ_LOGO.png" alt="image here">
</div>

<?php get_services_in_services_page(); ?>

<?php include('includes/footer.php') ?>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>