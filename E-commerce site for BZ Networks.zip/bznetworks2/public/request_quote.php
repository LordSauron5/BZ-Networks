<?php 



?>

<!DOCTYPE html>
<html lang="en">
<?php include('includes/header.php') ?>

<div class="stuff">
    <div class="container row quote-header">
        <div class="col s12 center quote-title">
            <span class="blue-text text-darken-2">
                <h3>I Need a Quote!</h3>
            </span>
            <span class="black-text"><hr class = "quote-des">
                <p>Our team at BZ Networks are ready to take on your request. Let us know what you need and we will get back to you as soon as possible! With your provided details we can generate an estimate quote to get you started.</p><hr class = "about-des">
            </span>
        </div>
    </div>
</div>

<div class="container">
<div class="card-panel blue darken-1"><span class="white-text text-darken-2 center"><h5>Please fill out the form below</h5></span></div>

<div class="row">
    <form class="col s12" action = "https://formspree.io/mjvojpnz" method = "POST" target = "_blank">
      <div class="row">
        <div class="input-field col s6">
          <i class="material-icons prefix">person</i>  
          <input id="first_name" type="text" class="validate" name = "First Name" required>
          <label for="first_name">First Name</label>
        </div>
        <div class="input-field col s6">
          <i class="material-icons prefix">person</i>
          <input id="last_name" type="text" class="validate" name = "Last Name" required>
          <label for="last_name">Last Name</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <i class="material-icons prefix">drafts</i>
          <input id="email" type="email" class="validate" name = "Email address" required>
          <label for="email">Email</label>
        </div>

        <div class="row">
          <div class="input-field col s6">
          <i class="material-icons prefix">phone</i>
            <input id="phone" type="text" data-length="10" class="validate" name = "contact number" required>
            <label for="input_text">Tel / Phone Number</label>
          </div>
        </div>

        <div class="input-field col s12">
        <i class="material-icons prefix">work</i>
          <select class="validate" name = "Establishment">
            <option value="" disabled selected>Select an option</option>
            <option value="Home">Home</option>
            <option value="Business">Business</option>
            <option value="Other">Other</option>
          </select>
          <label>For my Home / Business</label>
        </div>

        <div class="input-field col s12" required>
        <i class="material-icons prefix">style</i>
          <select class="validate" name = "Service needed">
            <option value="" disabled selected>Select a service</option>
            <option value="network-cabling">Office and Home network cabling</option>
            <option value="wifi">Office and Home Wifi</option>
            <option value="CCTV">CCTV</option>
            <option value="Intercom">Intercom</option>
            <option value="point-to-point-installation">Point-to-Point Installation</option>
            <option value="PA-Systems">PA Systems</option>
            <option value="Audio-Visual-Installation">Audio Visual Installation</option>
            <option value="other">Other</option>
          </select>
          <label>Service Options</label>
        </div>

        <div class="row">
        <div class="input-field col s12">
        <i class="material-icons prefix">mode_edit</i>
          <textarea id="requirements" name = "requirements" class="materialize-textarea validate" ></textarea>
          <label for="textarea1">Additional Requirements</label>
        </div>
      </div>
      <div class="row">
        <div class="col 6">
            <button class="btn waves-effect waves-light blue darken-2" type="submit" name="action">Submit
            <i class="material-icons right">send</i>
            </button>
        </div>
                <div class="col 6">
            <button class="btn waves-effect waves-light " type="submit">Clear Fields
            <i class="material-icons right">clear</i>
            </button>
        </div>
      </div>
      </div>
    </form>
  </div>

</div>

<?php include('includes/footer.php') ?>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>