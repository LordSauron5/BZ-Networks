<?php 

// helper functions

function last_id() {
    global $connection;

    return mysqli_insert_id($connection);
}

function set_message($msg) {
    if (!empty($msg)) {
        $_SESSION['message'] = $msg;
    }else {
        $msg = "";
    }
}

function display_message() {

    if(isset($_SESSION['message'])){

        echo $_SESSION['message'];
        unset($_SESSION['message']);

    }

}

function redirect($location){
    header("Location: $location ");
}

function query($sql) {

    global $connection; //this is to specify we not trying to make a new variable


    return mysqli_query($connection, $sql);
}

function confirm($result){

    global $connection;

    if(!$result) {
        die("QUERY FAILED " . mysqli_error($connection));
    }
}

function escape_string($string){
    global $connection;
    return mysqli_real_escape_string($connection, $string);
} 
    
function fetch_array($result){
    return mysqli_fetch_array($result);
}

/***************************FRONT END FUNCTIONS****************************** */


// get products

function get_products() {
    $query = query(" SELECT * FROM products");
    confirm($query);

    while ($row = fetch_array($query)) {
        $product = <<<DELIMETER
        <div class="col-sm-4 col-lg-4 col-md-4">
<div class="thumbnail">
    <a href = "item.php?id={$row['product_id']}"><img src="{$row['product_image']}" alt=""></a>
    <div class="caption">
        <h4 class="pull-right">R{$row['product_price']}</h4>
        <h4><a href="item.php?id{$row['product_id']}">{$row['product_title']}</a>
        </h4>
        <p>See more snippets like this online store item at <a target="_blank" href="http://www.bootsnipp.com">Bootsnipp - http://bootsnipp.com</a>.</p>
            <a class="btn btn-primary" target="_blank" href="../resources/cart.php?add={$row['product_id']}">Add to cart</a>
    </div>
</div>
</div>
DELIMETER;
//for the heradoc, this closing delimeter has to be at the beginning of the line and no spaces must be placed after it, not even after the comma
echo $product;
    }
}

function get_categories() {
    $query = query("SELECT * FROM categories");
    confirm($query);

    while ($row = fetch_array($query)) {
$categories_links = <<<DELIMETER

<a href='category.php?id={$row['cat_id']}' class='list-group-item'>{$row['cat_title']}</a>

DELIMETER;
echo $categories_links;
    }
}



function get_products_in_cat_page() {
    $query = query(" SELECT * FROM products WHERE product_category_id = " . escape_string($_GET['id']). " ");
    confirm($query);

    while ($row = fetch_array($query)) {
        $product = <<<DELIMETER
<div class="col-md-3 col-sm-6 hero-feature">
<div class="thumbnail">
<a href = "item.php?id={$row['product_id']}"><img src="{$row['product_image']}" alt=""></a>
    <div class="caption">
        <h3><a href="item.php?id{$row['product_id']}">{$row['product_title']}</h3></a>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        <p>
            <a href="#" class="btn btn-primary">Buy Now!</a> <a href="item.php?id={$row['product_id']}" class="btn btn-default">More Info</a>
        </p>
    </div>
</div>
</div>
DELIMETER;
//for the heradoc, this closing delimeter has to be at the beginning of the line and no spaces must be placed after it, not even after the comma
echo $product;
    }
}


function get_products_in_shop_page() {
    $query = query(" SELECT * FROM product ");
    confirm($query);

    while ($row = fetch_array($query)) {
        $product = <<<DELIMETER
<div class="col s12 m6 l3">
<div class="card hoverable">
    <div class="card-image">
    <img src="{$row['item_image']}">
    <a href="../resources/cart.php?add={$row['product_id']}" class="btn-floating halfway-fab waves-effect waves-light blue btn tooltipped" data-position="right" data-tooltip="Add To Cart"><i class="material-icons">add</i></a>
    </div>
    <div class="card-panel">
    <span class="card-title blue-text text-darken-5 ">{$row['item_title']} R{$row['item_price']}</span>
    </div>
    <div class="card-content">
    <p>{$row['item_description']}</p>
    </div>
</div>  
</div>
DELIMETER;
//for the heradoc, this closing delimeter has to be at the beginning of the line and no spaces must be placed after it, not even after the comma
echo $product;
    }
}

/************************ Admin Services Functions ********************/

function retrieve_services_for_Admin(){ // get the products in the admin view products table
    $query = query(" SELECT * FROM service");
    confirm($query);
    while($row = fetch_array($query)) {
        $service = <<<DELIMETER
        <tr>
            <td>{$row['service_title']}<br>
        <a href="index.php?edit_service&id={$row['service_id']}"><img width='100' src="{$row['service_image']}" alt=""></a>
            </td>
            <td>{$row['service_description']}</td>
            <td>R{$row['service_price']}</td>
                <td><a class="btn btn-danger" href="../../resources/actions/back/delete_service.php?delete_service_id={$row['service_id']}"><span class="glyphicon glyphicon-remove"></span></a></td>
        </tr>    
DELIMETER;
echo $service;
    }
}

/***************************Add Services to database********************/
function add_service() {
    if(isset($_POST['publish'])) {
        $title          = escape_string($_POST['title']);
        $price          = escape_string($_POST['price']);
        $description    = escape_string($_POST['description']);
        $image          = escape_string($_POST['image']);   
        $query = query("INSERT INTO `service` (`service_id`, `service_title`, `service_description`, `service_price`, `service_image`) VALUES (NULL, '{$title}', '{$description}', '{$price}', '{$image}')");
        $last_id = last_id();
        confirm($query);
        set_message("New Service with id {$last_id} was Added");
        redirect("index.php?services"); 
    }      
}

/***************************Admin Client Related Functions****************************** */

function display_clients(){
    $query = query(" SELECT * FROM client");
    confirm($query);
    while($row = fetch_array($query)) {
        $client = <<<DELIMETER
        <tr>
            <td>{$row['customer_id']}</td>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['email_address']}</td>
            <td>{$row['cell_no']}</td>
            <td>{$row['physical_address']}</td>
        </tr>    
DELIMETER;
echo $client;
    }    
}


/************************ Admin Products Functions ********************/

function retrieve_products_for_Adding(){ // get the products in the admin view products table
    $query = query(" SELECT * FROM product");
    confirm($query);
    while($row = fetch_array($query)) {
        $product = <<<DELIMETER
        <tr>
            <td>{$row['product_id']}</td>
            <td>{$row['item_title']}<br>
        <a href="index.php?edit_product&id={$row['product_id']}"><img width='100' src="{$row['item_image']}" alt=""></a>
            </td>
            <td>{$row['item_description']}</td>
            <td>R{$row['item_price']}</td>
            <td>{$row['item_quantity']}</td>
                <td><a class="btn btn-danger" href="../../resources/actions/back/delete_product.php?delete_product_id={$row['product_id']}"><span class="glyphicon glyphicon-remove"></span></a></td>
        </tr>    
DELIMETER;
echo $product;
    }
}

/***************************Add Products to database********************/
function add_product() {
    if(isset($_POST['publish'])) {
        $title          = escape_string($_POST['title']);
        $price          = escape_string($_POST['price']);
        $description    = escape_string($_POST['description']);
        $quantity       = escape_string($_POST['quantity']);
        $image          = escape_string($_POST['image']);   
        $query = query("INSERT INTO `product` (`product_id`, `item_title`, `item_description`, `item_quantity`, `item_price`, `item_image`) VALUES (NULL, '{$title}', '{$description}', '{$quantity}', '{$price}', '{$image}')");
        $last_id = last_id();
        confirm($query);
        set_message("New Product with id {$last_id} was Added");
        redirect("index.php?products"); 
    }      
}
function login_user() {
    if(isset($_POST['submit'])){


        $username = escape_string($_POST['username']);
        $email = escape_string($_POST['username']);
        $password = escape_string($_POST['password']);
        
        $results = query("SELECT * FROM user WHERE username = '{$username}' AND password = '{$password}' LIMIT 1");
        confirm($results);

        // $client = query("
        // SELECT user.user_id, client.customer_id
        // FROM client 
        // JOIN user ON user.user_id = client.user_id
        // WHERE user.user_id = {$_SESSION['user_id']};
        // ");
        // confirm($client_results);
        
        if (empty($username) && empty($password)) {
            set_message("Fields are empty");
            redirect("login.php");
        }else if (empty($username)) {
            set_message("Username is required");
            redirect("login.php");
        }else if(empty($password)) {
            set_message("Password is required");
            redirect("login.php");
        }

        if (mysqli_num_rows($results) == 1) { // user found
			// check if user is admin or user
			 $logged_in_user = mysqli_fetch_assoc($results);
			if ($logged_in_user['type'] == 'admin') {

				$_SESSION['username'] = $username;
				$_SESSION['success']  = "You are now logged in";
				header('location: admin/index.php');		  
			}else{
                $_SESSION['username'] = $username;
                $_SESSION['user_id'] = $logged_in_user['user_id'];
				$_SESSION['success']  = "You are now logged in";

				header('location: index.php');
			}
		}else {
            set_message("Wrong username/password combination");
            redirect("login.php");
		}


        // if(mysqli_num_rows($query) == 0) {
        //     set_message("You Password or Username are wrong");
        //     redirect("login.php");
        // }else {
        //     $_SESSION['username'] = $username;
        //     set_message("Welcome to user {$username}");
        //     redirect("login.php");
        // }


    }
}

//Beginning of registration process
function register_user(){
    if(isset($_POST['submit'])){


        $username = escape_string($_POST['username']);
        $fname = escape_string($_POST['fname']);
        $lname = escape_string($_POST['lname']);
        $email = escape_string($_POST['email']);
        $contact = escape_string($_POST['contact']);
        $password = escape_string($_POST['password']);
        $password2 = escape_string($_POST['password2']);
        $home = escape_string($_POST['home']);
        
        // $results = query("SELECT * FROM user WHERE username = '{$username}' AND password = '{$password}' LIMIT 1");
        // confirm($results); 
        check_empty_register($username, $fname, $lname, $email, $contact, $password, $password2, $home);
    }
}

function check_empty_register($username, $fname, $lname, $email, $contact, $password, $password2, $home){
    $error =false;
    $required = array($username, $fname, $lname, $email, $contact, $password, $password2, $home);
    foreach ($required as $field) {
        if (empty($field)){
            $error = true;
        }
    }

    if($error){
        set_message("Please enter all fields");
        redirect("register.php");
    }elseif ($password != $password2) {
        set_message("password must be the same");
        redirect("register.php");
    }else{
        create_new_user($username, $fname, $lname, $email, $contact, $password, $password2, $home);
    }
}

function create_new_user($username, $fname, $lname, $email, $contact, $password, $password2, $home){
    $query = query(" INSERT INTO `user` (`user_id`, `username`, `password`, `type`) VALUES (NULL, '{$username}', '$password', 'customer')");
    confirm($query);

    $findLastUser = query("SELECT * FROM user where type ='customer' ORDER BY user_id DESC LIMIT 1");
    confirm($findLastUser);
    $resultUser = mysqli_fetch_assoc($findLastUser);//pass results to an array
    $userID = $resultUser['user_id'];
    $insertClient = query("INSERT INTO `client` (`customer_id`, `user_id`, `first_name`, `last_name`, `email_address`, `cell_no`, `physical_address`) VALUES (NULL, '{$userID}', '{$fname}', '{$lname}', '{$email}', '{$contact}', '{$home}')");
    confirm($insertClient);
    
    login_user();//once successfully registered, log the user in immediately

} //end of registration process

function send_message() {
    if(isset($_POST['submit'])){

        $to = "tyronaricum1@gmail.com"; //change this afterwards
        $from_name = $_POST['name'];
        $subject = $_POST['subject'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        $headers = "From: {$from_name} {$email}";
        $result = mail($to, $subject, $message, $headers);
        if(!$result){
            set_message("Sorry we could not send your message");
        }else {
            set_message("Your message has been sent");
        } //smtp needs to be set up
    }
}

function get_services_in_services_page() {
    $query = query(" SELECT * FROM service ");
    confirm($query);

    while ($row = fetch_array($query)) {
        $service = <<<DELIMETER
<div class="service-container">
<div class="srv-title">
        <h4 class = "blue-text text-darken-2" >{$row['service_title']}</h4>
    </div>
<div class="srv-row">
    <div class="srv-image">
        <img src="{$row['service_image']}" alt="">
    </div>

    <div class="srv-description ">
        <p>
        {$row['service_description']}
        </p>
    </div>
</div>
</div>
DELIMETER;
//for the heradoc, this closing delimeter has to be at the beginning of the line and no spaces must be placed after it, not even after the comma
echo $service;
    }
}

/***************************BACK END FUNCTIONS****************************** */
function display_orders() {
    $query = query("SELECT * FROM orders");
    confirm($query);

    while ($row = fetch_array($query)) {
        $orders = <<<DELIMETER

        <tr>
            <td>{$row['order_id']}</td>
            <td>{$row['customer_id']}</td>
            <td>R {$row['order_amount']}</td>
            <td>{$row['order_status']}</td>
            <td>{$row['payment_status']}</td>
            <td><a class = "btn btn-success" data-toggle="tooltip" data-placement="top" title = "Order Complete" href = "../../resources/actions/back/update_order_status.php?update_order_status_id={$row['order_id']}"><span class = " glyphicon glyphicon-ok "></span></a>
            <a class = "btn btn-info" title = "Payment Received" href = "../../resources/actions/back/update_order_payment.php?update_payment_id={$row['order_id']}"><span class = "glyphicon glyphicon-usd"></span></a>
            <a class = "btn btn-danger" title = "Delete Order" href = "../../resources/actions/back/delete_order.php?delete_order_id={$row['order_id']}"><span class = "glyphicon glyphicon-remove"></span></a></td>
            </tr>                                               

DELIMETER;
echo $orders;
    }
}

function get_orders_to_dash(){

    $query = query("SELECT orders.order_id, client.customer_id, client.first_name, orders.order_amount, orders.order_status, orders.payment_status FROM orders JOIN client on client.customer_id = orders.customer_id");
    confirm($query);

    while ($row = fetch_array($query)) {
        $orders = <<<DELIMETER

        <tr>
            <td>{$row['order_id']}</td>
            <td>{$row['customer_id']}</td>
            <td>{$row['first_name']}</td>
            <td>R {$row['order_amount']}</td>
            <td>{$row['order_status']}</td>
            <td>{$row['payment_status']}</td>
        </tr>

DELIMETER;
echo $orders;
    }    
}

function get_clients_to_dash(){

    $query = query("SELECT * FROM client");
    confirm($query);

    while ($row = fetch_array($query)) {
        $client = <<<DELIMETER

        <tr>
            <td>{$row['customer_id']}</td>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['email_address']}</td>
        </tr>

DELIMETER;
echo $client;
    }    
}

function new_orders_to_dash(){
    $orders = query("SELECT * FROM orders Where order_status = 'pending'");
    confirm($orders);
    $number_of_orders = mysqli_num_rows($orders);

    echo $number_of_orders;
}

function total_products_to_dash(){
    $products = query("SELECT * FROM product");
    confirm($products);
    $number_of_products = mysqli_num_rows($products);

    echo $number_of_products;
}
?>