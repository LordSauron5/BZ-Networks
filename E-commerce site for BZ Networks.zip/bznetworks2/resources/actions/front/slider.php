<div class="slider">
    <ul class="slides">
      <li>
        <img src="./assets/white-and-blue-cables-2881229.jpg"> <!-- slide image -->
        <div class="caption center-align">
          <h3>Network Solutions, Made Simple!</h3>
          <h5 class="light grey-text text-lighten-3">Affordable services for all your networking needs.</h5>
        </div>
      </li>
      <li>
        <img src="./assets/pexels-burst-374085"> <!-- slide image -->
        <div class="caption left-align">
          <h3>Keeping You Connected</h3>
          <h5 class="light grey-text text-lighten-3">Home or Business, we make it possible.</h5>
        </div>
      </li>
      <li>
        <img src="./assets/pexels-scott-webb-430208.jpg"> <!-- slide image -->
        <div class="caption right-align">
          <h3>Surveillance, For your security</h3>
          <h5 class="light grey-text text-lighten-3">Quick installations to keep you protected.</h5>
        </div>
      </li>
      <li>
        <img src="./assets/pexels-joseph-redfield-1870438.jpg"> <!-- slide image -->
        <div class="caption center-align">
          <h3>Audio Visual Services</h3>
          <h5 class="light grey-text text-lighten-3">You need it done? we'll get it done!</h5>
        </div>
      </li>
    </ul>
</div>