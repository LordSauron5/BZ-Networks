
<h1 class="page-header">
   All Services

</h1>

<h3 class="bg-success"><?php display_message(); ?></h3>
<table class="table table-hover">


    <thead>

      <tr>
           <th>Service Title</th>
           <th>Description</th>
           <th>Price</th>
      </tr>
    </thead>
    <tbody>

      
      <?php retrieve_services_for_Admin(); ?>


  </tbody>
</table>



