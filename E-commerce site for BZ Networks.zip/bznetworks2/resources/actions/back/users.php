
<div class="col-lg-12">
    

    <h1 class="page-header">
        All Clients
        
    </h1>
        <p class="bg-success">
        
    </p>
    <div class="col-md-12">

        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Customer ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email Address</th>
                    <th>Phone Number</th>
                    <th>Address</th>
        
                </tr>
            </thead>
            <tbody>
                    <?php display_clients(); ?> 
            </tbody>
        </table> <!--End of Table-->
    

    </div>

    
</div>
    


