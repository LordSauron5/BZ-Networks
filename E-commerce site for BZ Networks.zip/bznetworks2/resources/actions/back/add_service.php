<?php add_service(); ?>
<div class="col-md-12">

<div class="row">
<h1 class="page-header">
   Add Service
</h1>
</div>
<form action="" method="post" enctype="multipart/form-data">


<div class="col-md-8">

<div class="form-group">
    <label for="title">Service Title</label>
        <input type="text" name="title" class="form-control">
    </div>


    <div class="form-group">
           <label for="description">Service Description</label>
      <textarea name="description" id="" cols="30" rows="10" class="form-control"></textarea>
    </div>



    <div class="form-group row">

      <div class="col-xs-3">
        <label for="price">Service Price</label>
        <input type="number" name="price" class="form-control" size="60">
      </div>
    </div>



    <div class="form-group">
           <label for="image">URL to Image</label>
           <input type="text" name="image" class="form-control">
    </div>
</div><!--Main Content-->


<!-- SIDEBAR-->


<aside id="admin_sidebar" class="col-md-4">  
     <div class="form-group">
       <input type="reset" class="btn btn-warning btn-lg" value="Clear all Fields">
        <input type="submit" name="publish" class="btn btn-primary btn-lg" value="Add Service">
    </div>
</aside><!--SIDEBAR-->


    
</form>
