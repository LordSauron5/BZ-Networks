<?php require_once("../../config.php");

if(isset($_GET['update_order_status_id'])) {

$query = query("UPDATE orders SET `order_status` = 'Complete', `payment_status` = 'Received' WHERE order_id = " . escape_string($_GET['update_order_status_id']) . " "); 
confirm($query);


set_message("Order Status Updated");
redirect("../../../public/admin/index.php?orders");


} else {
set_message("Error in Updating Order Status");
redirect("../../../public/admin/index.php?orders");


}



 ?>