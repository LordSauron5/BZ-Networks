<?php require_once("../../config.php");

if(isset($_GET['delete_order_id'])) {


$query = query("DELETE FROM orders WHERE order_id = " . escape_string($_GET['delete_order_id']) . " "); // currently foreign key restriction
confirm($query);


set_message("Order Deleted");
redirect("../../../public/admin/index.php?orders");


} else {
set_message("Error in deleting Order");
redirect("../../../public/admin/index.php?orders");


}



 ?>