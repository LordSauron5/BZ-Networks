<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav">
        <li>
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li>
            <a href="index.php?orders"><i class="fa fa-fw fa-bar-chart-o"></i> View Orders</a>
        </li>
        <li>
            <a href="index.php?products"><i class="fa fa-shopping-cart"></i> View Products</a>
        </li>
        <li>
            <a href="index.php?add_product"><i class="fa fa-shopping-cart"></i> Add Product</a>
        </li>
        
        <li>
            <a href="index.php?services"><i class="fa fa-suitcase"></i> View Services</a>
        </li>
        <li>
            <a href="index.php?add_service"><i class="fa fa-suitcase"></i> Add Service</a>
        </li>
        <li>
            <a href="index.php?users"><i class="fa fa-group"></i> Clients</a>
        </li>
    
    </ul>
</div>
<!-- /.navbar-collapse -->