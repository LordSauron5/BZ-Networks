<?php require_once("../../config.php");

if(isset($_GET['delete_service_id'])) {


$query = query("DELETE FROM service WHERE service_id = " . escape_string($_GET['delete_service_id']) . " "); 
confirm($query);


set_message("Service Deleted");
redirect("../../../public/admin/index.php?services");


} else {
set_message("Error in deleting Service");
redirect("../../../public/admin/index.php?services");


}



 ?>