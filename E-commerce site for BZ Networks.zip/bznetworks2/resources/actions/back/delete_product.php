<?php require_once("../../config.php");

if(isset($_GET['delete_product_id'])) {
$query = query("DELETE FROM product WHERE product_id = " . escape_string($_GET['delete_product_id']) . " ");
confirm($query);
set_message("Product Deleted");
redirect("../../../public/admin/index.php?products");
} else {
set_message("Error Deleting product");
redirect("../../../public/admin/index.php?products");
}

?>