<?php require_once("../../config.php");

if(isset($_GET['update_payment_id'])) {

$query = query("UPDATE orders SET `payment_status` = 'Received' WHERE order_id = " . escape_string($_GET['update_payment_id']) . " ");
confirm($query);


set_message("Payment Status updated");
redirect("../../../public/admin/index.php?orders");


} else {
set_message("Error in Updating Payment Status");
redirect("../../../public/admin/index.php?orders");


}



 ?>