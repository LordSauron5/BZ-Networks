
<!-- Configuration-->

<?php require_once("config.php"); ?>

<?php 

if (isset($_GET['add'])) {
    
    $query = query("SELECT * FROM product WHERE product_id=" . escape_string($_GET['add']) . " ");
    confirm($query);

    while($row = fetch_array($query)){
        if ($row['item_quantity'] != $_SESSION['product_' . $_GET['add']]) {
            $_SESSION['product_' . $_GET['add']] +=1;
            redirect("../public/checkout.php");

        }else {
            set_message("We only have " . $row['item_quantity'] . " " . $row['item_title'] . " available");
            redirect("../public/checkout.php");
        }
    }

    // $_SESSION['product_' . $_GET['add']] +=1;
    // redirect("index.php");

}

if (isset($_GET['remove'])) {
    $_SESSION['product_' . $_GET['remove']]--;
    if ($_SESSION['product_' . $_GET['remove']]<1) {
        unset($_SESSION['item_total']);
        unset($_SESSION['item_quantity']);
        redirect("../public/checkout.php");
    }else {
        redirect("../public/checkout.php");
    }
}

if (isset($_GET['delete'])) {
    $_SESSION['product_' . $_GET['delete']] = '0';
    unset($_SESSION['item_total']);
    unset($_SESSION['item_quantity']);
    redirect("../public/checkout.php");

}

function cart() {

$total = 0;
$item_quantity = 0;
$item_name = 1;
$item_number = 1;
$amount = 1;
$quantity = 1;

    foreach ($_SESSION as $name => $value) {
        if ($value > 0) {

if(substr($name, 0, 8) == "product_"){ //checks which product we are refering to
$length = strlen($name) - 8; //exclude the prefix
$id = substr($name, 8, $length); //name of the product

                $query = query("SELECT * FROM product WHERE product_id = " . escape_string($id) . " ");
                confirm($query);
                while ($row = fetch_array($query)) {
$sub = $row['item_price'] * $value; //to get sub total of item
$item_quantity += $value;
$product = <<<DELIMETER
                
                <tr>
                <td>{$row['item_title']}</td>
                <td>R{$row['item_price']}</td>
                <td>{$value}</td>
                <td>R$sub</td>
                <td>
                    <a class = 'btn amber accent-3 tooltipped' data-position="top" data-tooltip="remove" href="../resources/cart.php?remove={$row['product_id']}"><i class="large material-icons">remove</i></a>
                    <a class = 'btn light-green accent-3 tooltipped' data-position="top" data-tooltip="add" href="../resources/cart.php?add={$row['product_id']}"><i class="large material-icons">add</i></a>
                    <a class = 'btn deep-orange tooltipped' data-position="top" data-tooltip="delete from cart" href="../resources/cart.php?delete={$row['product_id']}"><i class="large material-icons">close</i></a>
                </td>
                
                </tr>
                <input type="hidden" name="item_name_{$item_name}" value="{$row['item_title']}">
                <input type="hidden" name="item_number_{$item_number}" value="{$row['product_id']}">
                <input type="hidden" name="amount_{$amount}" value="{$row['item_price']}">                
                <input type="hidden" name="quantity_{$quantity}" value="{$value}">                
DELIMETER;
echo $product;
$item_name++;
$item_number++;
$amount++;
$quantity++;
               }
 $_SESSION['item_total'] = $total += $sub;
 $_SESSION['item_quantity'] = $item_quantity;
            }
        }
    }
}

function show_paypal() { //display the buy button
    if(isset($_SESSION['item_quantity']) && $_SESSION['item_quantity'] >=1 ){
        $paypal_button = <<<DELIMETER
        <input type="image" name="upload"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
        alt="PayPal - The safer, easier way to pay online">
DELIMETER;
return $paypal_button;
    }
}




function process_transaction() {

    if (isset($_GET['tx'])) {
        $amount = $_GET['amt'];
        $currency = $_GET['cc'];
        $transaction = $_GET['tx'];
        $status = $_GET['st'];

    $total = 0;
    $item_quantity = 0;

    
        foreach ($_SESSION as $name => $value) {
            if ($value > 0) {//value = quanity per item
    
    if(substr($name, 0, 8) == "product_"){ //checks which product we are refering to
    $length = strlen($name) - 8; //exclude the prefix
    $id = substr($name, 8, $length); //name of the product

    $send_order = query("INSERT INTO orders (order_amount, order_transaction, order_status, order_currency) VALUES('{$amount}', '{$transaction}', '{$status}', '{$currency}')"); 
    $last_id = last_id();
    confirm($send_order);
    
    $query = query("SELECT * FROM product WHERE product_id = " . escape_string($id) . " ");
    confirm($query);
    while ($row = fetch_array($query)) {
    $product_price = $row['product_price'];
    $product_title = $row['product_title'];
    $sub = $row['product_price'] * $value; //to get sub total of item
    $item_quantity += $value;

    $insert_report = query("INSERT INTO reports (product_id, order_id, product_title, product_price, product_quantity) VALUES('{$id}', '{$last_id}', '{$product_title}', '{$product_price}', '{$value}')");
    confirm($insert_report);

                   }
$total += $sub;
echo $item_quantity;
                }
            }
        }

session_destroy(); //after an insert is made, destroy the session
    } else {
        redirect("index.php");
    }
}

/***************************
 * All functions preceding the order placement
 **************************** */
function place_order() {
    if(isset($_SESSION['item_quantity']) && $_SESSION['item_quantity'] >=1 ){
        $order_button = <<<DELIMETER
        <!-- Modal Trigger -->
        <a class="waves-effect waves-light btn waves-effect waves-green green accent-3 modal-trigger" href="#modal1">Checkout Items</a>
      
        <!-- Modal Structure -->
        <div id="modal1" class="modal">
          <div class="modal-content center">
            <h4>Payment Method</h4>
            <p>Select a method of Payment</p>
          </div>
          <div class="modal-text center">
            <a href="../resources/cart.php?cash" class="modal-close waves-effect waves-green btn-flat btn green accent-3">Pay Cash</a>
            <button class = "btn waves-effect waves-light" type="submit" name = "paypal" value "paypal" >Pay via PayPal<i class="material-icons right">attach_money</i></button>
          </div>
        </div>
DELIMETER;
return $order_button;
    }   
}

if (isset($_GET['cash'])) {
    //insert into database
    create_order_record();
    redirect("../public/thank_you.php");

    //redirect back to checkout page
}

if (array_key_exists('paypal', $_POST)) {
    //insert into database
    create_order_record();
    redirect("../public/thank_you_paypal.php");

    //redirect back to checkout page
}

function create_order_record(){
//    $insertItem = query("SELECT * FROM product WHERE product_id = " . escape_string($id) . " "); 

$total = 0;
$item_quantity = 0;
$item_name = 1;
$item_number = 1;
$amount = 1;
$quantity = 1;

    foreach ($_SESSION as $name => $value) {
        if ($value > 0) {

if(substr($name, 0, 8) == "product_"){ //checks which product we are refering to
$length = strlen($name) - 8; //exclude the prefix
$id = substr($name, 8, $length); //name of the product

                $query = query("SELECT * FROM product WHERE product_id = " . escape_string($id) . " ");
                confirm($query);
                while ($row = fetch_array($query)) {
$sub = $row['item_price'] * $value; //to get sub total of item
$item_quantity += $value;

echo $item_name;
echo $item_number;
echo $item_quantity;

$item_name++;
$item_number++;
$amount++;
$quantity++;
               }
 $_SESSION['item_total'] = $total += $sub;
 $_SESSION['item_quantity'] = $item_quantity;

            }
        }
    }
    $user_id = $_SESSION['user_id'];
    $client_id = $_SESSION['client_id'];

    $findCustomerID = query("
    SELECT user.user_id, client.customer_id
    FROM client 
    JOIN user ON user.user_id = client.user_id
    WHERE user.user_id = {$user_id}; 
    ");                                         //query to find customer ID of user
    confirm($findCustomerID);
    $resultUser = mysqli_fetch_assoc($findCustomerID);//pass results to an array
    $client_id = $resultUser['customer_id'];
    $createOrder = query("INSERT INTO `orders` (`order_id`, `customer_id`, `order_amount`, `order_status`, `payment_status`) VALUES (NULL, '{$client_id}', '{$total}', 'Pending', 'Pending')");
    confirm($createOrder);
    items_collection();
}

function items_collection(){
    $order = $_SESSION['order_id'];

    $findLastOrder = query("SELECT * FROM orders ORDER BY order_id DESC LIMIT 1");
    confirm($findLastOrder);
    $resultOrder = mysqli_fetch_assoc($findLastOrder);//pass results to an array
    $order = $resultOrder['order_id'];

$total = 0;
$item_quantity = 0;
$item_name = 1;
$item_number = 1;
$amount = 1;
$quantity = 1;

    foreach ($_SESSION as $name => $value) {
        if ($value > 0) {

if(substr($name, 0, 8) == "product_"){ //checks which product we are refering to
$length = strlen($name) - 8; //exclude the prefix
$id = substr($name, 8, $length); //name of the product

                $query = query("SELECT * FROM product WHERE product_id = " . escape_string($id) . " ");
                confirm($query);
                while ($row = fetch_array($query)) {
$sub = $row['item_price'] * $value; //to get sub total of item
$item_quantity += $value;

echo $item_name;
echo $item_number;
echo $item_quantity;

$createInsert = query("INSERT INTO `items_list` (`list_id`, `quote_no`, `order_no`, `product_id`, `quantity`) VALUES (NULL, NULL, '{$order}', '{$item_number}', '{$value}')");
confirm($createInsert);

$item_name++;
$item_number++;
$amount++;
$quantity++;
               }
 $_SESSION['item_total'] = $total += $sub;
 $_SESSION['item_quantity'] = $item_quantity;

            }
        }
    }
}

?>

