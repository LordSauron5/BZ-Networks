-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 21, 2020 at 08:04 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bz_networksdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `cell_no` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='admin details';

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user_id`, `first_name`, `last_name`, `email_address`, `cell_no`) VALUES
(1, 10, 'Antonio', 'Armino', 'tony@bznetworks.co.za', '0827101570'),
(2, 11, 'Tyron', 'Aricum', 'tyronaricum1@gmail.com', '0790877987');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `cell_no` varchar(255) NOT NULL,
  `physical_address` text NOT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1 COMMENT='client details';

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`customer_id`, `user_id`, `first_name`, `last_name`, `email_address`, `cell_no`, `physical_address`) VALUES
(110, 13, 'June', 'Summerlin', 'JuneJSummerlin@armyspy.com ', '914-458-3206', '3416 Mount Tabor\r\nNew York, NY 10013 '),
(111, 16, 'Kyle', 'McAllister', 'KyleKMcAllister@jourrapide.com ', '925-829-9273', '2521 Beech Street\r\nSan Ramon, CA 94583 '),
(112, 14, 'Michael', 'Pelletier', 'MichaelLPelletier@teleworm.us ', '281-577-2767', '1373 Bird Spring Lane\r\nPorter, TX 77365'),
(113, 15, 'Holly', 'Daniel', 'HollyJDaniel@rhyta.com ', '831-824-4832', '2417 Cemetery Street\r\nSan Francisco, CA 94104 '),
(118, 24, 'Barry', 'Blue', 'barryblueb@chimpmail.com', '0215056487', '24 mapel street, Winchester, 72223'),
(119, 25, 'James', 'Camerons', 'jcameron3@freemail.com', '02111354468', '13 Albion newtown 3354'),
(120, 26, 'ndai', 'mapaso', 'ndaimapaso@gmail.com', '021549687654', '43 new strtee 5646543'),
(121, 27, 'Blake', 'Paul', 'blakepaul21@gmail.com', '0654688456', '32 lawrence street gevon 5585'),
(122, 28, 'Ndai', 'Mapaso', 'ndaimapaso2@gmail.com', '07821544658', '13 Somewhere Street Java area 7785');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
CREATE TABLE IF NOT EXISTS `invoice` (
  `invoice_no` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `description` text,
  `total` float NOT NULL,
  PRIMARY KEY (`invoice_no`),
  KEY `order_id` (`order_id`,`customer_id`),
  KEY `customers-invoice` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='invoice details';

-- --------------------------------------------------------

--
-- Table structure for table `items_list`
--

DROP TABLE IF EXISTS `items_list`;
CREATE TABLE IF NOT EXISTS `items_list` (
  `list_id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_no` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`list_id`),
  KEY `quote_no` (`quote_no`,`order_no`,`product_id`),
  KEY `items-for-order` (`order_no`),
  KEY `product-reference` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1 COMMENT='List of items to be quoted, invoiced or ordered';

--
-- Dumping data for table `items_list`
--

INSERT INTO `items_list` (`list_id`, `quote_no`, `order_no`, `product_id`, `quantity`) VALUES
(52, NULL, 71, 1, 2),
(53, NULL, 72, 1, 2),
(54, NULL, 72, 2, 1),
(55, NULL, 73, 1, 1),
(56, NULL, 74, 1, 1),
(57, NULL, 75, 1, 3),
(58, NULL, 75, 2, 1),
(59, NULL, 75, 3, 1),
(60, NULL, 76, 1, 3),
(61, NULL, 77, 1, 1),
(62, NULL, 78, 1, 1),
(63, NULL, 79, 1, 2),
(64, NULL, 79, 2, 1),
(65, NULL, 80, 1, 1),
(66, NULL, 81, 1, 1),
(67, NULL, 82, 1, 2),
(68, NULL, 83, 1, 2),
(69, NULL, 83, 2, 1),
(70, NULL, 84, 1, 3),
(71, NULL, 84, 2, 1),
(72, NULL, 85, 1, 13),
(73, NULL, 86, 1, 1),
(74, NULL, 86, 2, 2),
(75, NULL, 87, 1, 1),
(76, NULL, 88, 1, 1),
(77, NULL, 88, 2, 2),
(78, NULL, 89, 1, 1),
(79, NULL, 90, 1, 10),
(80, NULL, 91, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `order_amount` float NOT NULL,
  `order_status` varchar(255) NOT NULL DEFAULT 'Pending',
  `payment_status` varchar(255) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1 COMMENT='order details';

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `order_amount`, `order_status`, `payment_status`) VALUES
(71, 110, 7141.5, 'Pending', 'Pending'),
(72, 110, 7551.4, 'Pending', 'Pending'),
(73, 110, 10560, 'Pending', 'Pending'),
(74, 110, 3570.75, 'Complete', 'Received'),
(75, 118, 3619.28, 'Pending', 'Pending'),
(76, 111, 479.7, 'Pending', 'Received'),
(77, 118, 3570.75, 'Pending', 'Pending'),
(78, 112, 239.59, 'Complete', 'Received'),
(79, 110, 17701.5, 'Pending', 'Pending'),
(80, 110, 10560, 'Complete', 'Received'),
(81, 110, 10560, 'Pending', 'Received'),
(82, 119, 479.18, 'Complete', 'Received'),
(83, 120, 3921.73, 'Pending', 'Pending'),
(84, 120, 4097.22, 'Pending', 'Pending'),
(85, 110, 26000, 'Pending', 'Pending'),
(86, 121, 7316.99, 'Pending', 'Pending'),
(87, 118, 10560, 'Pending', 'Pending'),
(88, 122, 14860, 'Complete', 'Received'),
(89, 122, 239.59, 'Complete', 'Received'),
(90, 111, 1300, 'Pending', 'Pending'),
(91, 110, 260, 'Pending', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_title` varchar(255) NOT NULL,
  `item_description` text NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_price` float NOT NULL,
  `item_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COMMENT='product details';

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `item_title`, `item_description`, `item_quantity`, `item_price`, `item_image`) VALUES
(1, 'HKV DS-7608NI-K2/8P', 'Hikvision 8CH Embedded Plug & Play NVR H.265/H.264/H.264+/MPEG4, 8,6,5,4-3MP/1080p/UXGA/720p/VGA/4CIF, Video I/P 8xRJ45, TCP/IPx1/160Mbps, 2xSATA, 1xRJ45, 2xUSB 2.0-3.0, 1xHDMI, VGA, Alarm I/P&O/P,8x PoE, Up to 6TB Cap per disk.', 12, 3570.75, 'https://cdn.shopify.com/s/files/1/0075/8228/5897/products/I4273050317_1200x.jpg?v=1562608990'),
(2, 'S19 - Pots Filter', 'High-performance in-line DSL filter for phones or telephone equipment sharing a single phone jack. Isolates DSL and home phone line networking signals from voice signal for peak data performance and voice quality. Effectively filters one or more phone devices (standard or cordless phone, answering machine, dial-up modem, fax machine, etc.). Easy to install without tools – just plug the filter cord into any standard phone jack, and plug the phone cord into the filter. Provides a filtered jack for any single-line phone device plus a second unfiltered jack for DSL connection.', 32, 175.49, 'http://chintax.co.za/wp-content/uploads/2014/11/S19-Pots-Filter-300x300.jpg'),
(3, 'Acer K137i Portable, LED, WXGA Projector', 'Acer – K137i – Portable, LED, WXGA (1280×800), Apect ratio 16:10, 700 ANSI lumens, 10000/1 contrast ratio, Inputs: HDMI, USB, microSD reader, LED Life 20, 000hours, 2x3W speakers, Projection distance: 600mm – 3.2m, Max diagonal image 2.54m, Bag & remote included, USB WiFi adapter included, Dimensions: H 41mm x W 189mm x D 116mm, Weight 510g, 2 Year carry in warranty,', 5, 10560, 'https://static.acer.com/up/Resource/Acer/Projectors/AGW2%20Travel/Photo%20Gallery/20131026/K137-photo-gallery-02.png'),
(4, 'Antec Veris E Z remote control for MCE', 'Antec Veris E-Z remote control for MCE ( Media Center Edition ) , clipable design usb receiver for Lcd or notebook , designed by iMON , ideal for upgrading vista home preminum / ultimate to MCE , 18-keys , with bundled microsoft certified MPEG-2 encoder , reatil pack', 13, 239.59, 'https://www.avadirect.com/Pictures/500/1607205_3.jpg'),
(5, 'Kingston sna B HDD / SSD upgrade kit with cloning software', 'Kingston sna-B HDD  SSD upgrade kit with cloning software + 2.5 3.5 mounting bracket + 2.5 enclosure + USB CABLE', 20, 409.9, 'https://scylla.mobee.xyz/f_webp/w_420/q_90/https://thinkcomputers.org/wp-content/uploads/2019/04/UV500_01-Large-1000x561.jpg'),
(6, 'WD Purple 4TB 3.5 SATA3', 'WD Purple 4TB 3.5 SATA3 6.0Gbps Surveillance HDD,5400RPM, 64MB Cache, 150MB s Host to from (Sustained), AllFrame, HD Video Optimised, For DVR  NVR, 3-Year Warranty', 13, 2149.99, 'https://epyqgroup.co.za/it/wp-content/uploads/sites/4/2019/07/wd4tb_purple.jpg'),
(7, 'WD Purple 2TB 3.5', 'WD Purple 2TB 3.5 SATA3 6.0Gbps Surveillance HDD, 5400RPM, 64MB Cache, 145MBs Host to/from (Sustained), AllFrame, HD Video Optimised, For DVR  NVR, 3-Year Warranty', 13, 1379.5, 'https://technowave.co.za/45338-home_default/wd-purple-2tb-35-sata-64mb-hard-drive.jpg'),
(8, 'OEM 40m Pre Made BNC Cable', 'hese pre made cables will simplify your surveillance system installation by eliminating the need to cut cables and crimp the ends on yourself. If you need to extend the distance of your cable, you can connect two or more pre made cables together by using a BNC double female connector.\r\nProduct Highlights\r\n\r\nAll in one video and power cable\r\nPlug and Play ready', 6, 159.9, 'https://www.syntech.co.za/wp-content/uploads/2014/12/VP40M.jpg'),
(9, 'Sugar', '12 kilograms sugar', 10, 130, '');

-- --------------------------------------------------------

--
-- Table structure for table `quote`
--

DROP TABLE IF EXISTS `quote`;
CREATE TABLE IF NOT EXISTS `quote` (
  `quote_no` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `quote_description` text,
  `date` date NOT NULL,
  `valid_until` date NOT NULL,
  PRIMARY KEY (`quote_no`),
  KEY `quote-for-customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='quote details';

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_title` varchar(255) NOT NULL,
  `service_description` text,
  `service_price` float NOT NULL,
  `service_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COMMENT='services details';

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `service_title`, `service_description`, `service_price`, `service_image`) VALUES
(1, 'Office and Home network cabling', 'Our solution to all your data and voice cabling requirements. We provide solutions to homes, businesses, and other organisations. At BZ Networks, we provide guaranteed quality network solutions.', 1500, 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80'),
(2, 'Office and Home WIFI', 'Need wireless access everywhere you go? We\'ll have you up and running in a jiffy. We provide network access points, repairs to faulty network installations, and 24/7 operational WIFI', 1200, 'https://images.unsplash.com/photo-1592438710388-bf464c011df9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80'),
(3, 'CCTV', 'Closed-circuit television (CCTV), also known as video surveillance, is the use of video cameras to transmit a signal to a specific place, on a limited set of monitors. It differs from broadcast television in that the signal is not openly transmitted, though it may employ point to point (P2P), point to multipoint (P2MP), or mesh wired or wireless links. Though almost all video cameras fit this definition, the term is most often applied to those used for surveillance in areas that may need monitoring such as banks, stores, and other areas where security is needed.', 6500, 'https://images.unsplash.com/photo-1566060475410-1159300f046f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=967&q=80'),
(4, 'Intercoms', 'Two-way communication electronic device that contains circuitry for the purpose of transmitting and receiving audio and/or video transmissions.\r\n Wireless Intercoms: In applications where wires cannot be run, a wireless system is used. There are a broad spectrum of two-way wireless communication devices that include such devices as handheld radios, outdoor wireless callboxes, as well as traditional desktop devices. The range these units will transmit varies widely based on the wireless technology used.', 4200, 'https://images.unsplash.com/photo-1528817466667-942353411fee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80'),
(5, 'Point-to-Point Installations', 'A point-to-point connection refers to a communications connection between two nodes or endpoints.\r\n\r\nThe Point-to-Point Protocol (PPP) is used for establishing direct connectivity between two network nodes. It authenticates the connections, compresses, transmits after encryption thereby providing privacy. PPP is primarily designed for linking two networks and transporting IP packets between the two. The links are capable of providing simultaneous bi-directional functions, delivering data packets in a specific order. This protocol is a common solution to easily connect diverse types of hosts, bridges, and routers.', 3100, 'https://images.unsplash.com/photo-1528817466667-942353411fee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80'),
(6, 'PA Systems', 'PA stands for public address, i.e projecting sound to a large group of people louder than you could by talking or playing an acoustic instrument. Your first thought of PA speakers could be of those used at concerts or sports stadiums, but there are so many other applications for a PA system that one day you might have to buy one yourself.', 1700, 'https://images.unsplash.com/photo-1533621517681-fd36c2e12666?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'),
(7, 'Audio Visual Installations', 'BZ Networks can supply and install a large range of audio visual equipment to suit the individual needs of the customer. This includes a vast range of projectors which can be used to show films, presentations or add an extra dimension to stage scenery.  The projector market is fast moving with new and advanced products released regularly. In partnership with our suppliers, BZ Networks are able to offer the latest equipment which is tailored to meet the needs of the individual customer, all of which will be fully and sympathetically installed to compliment the other technology infrastructure in your facility.', 2200, 'https://images.unsplash.com/photo-1535016120720-40c646be5580?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

DROP TABLE IF EXISTS `slides`;
CREATE TABLE IF NOT EXISTS `slides` (
  `slide_id` int(11) NOT NULL AUTO_INCREMENT,
  `slide_title` varchar(255) NOT NULL,
  `slide_path` varchar(255) NOT NULL,
  PRIMARY KEY (`slide_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='slide details';

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'customer',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COMMENT='user details';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `type`) VALUES
(10, 'Belthezar', 'Admin#2020', 'admin'),
(11, 'Sauron', 'Admin#2020', 'admin'),
(13, 'Camble', 'aileiY8ahpee', 'customer'),
(14, 'Lofiressamed', 'Ohy8ahx8a', 'customer'),
(15, 'Behisellin', 'Rahlohse3kai', 'customer'),
(16, 'Exclasen', 'neaW9ohz', 'customer'),
(24, 'barrybluebird', 'Jackie2', 'customer'),
(25, 'jamescammie233', 'PasswordNew', 'customer'),
(26, 'ndai', 'Ndai1', 'customer'),
(27, 'Blake132', 'stopme2', 'customer'),
(28, 'ndaigamer2', 'Ndai1', 'customer');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin-user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client-user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `customers-invoice` FOREIGN KEY (`customer_id`) REFERENCES `client` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `order-for-invoice` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `items_list`
--
ALTER TABLE `items_list`
  ADD CONSTRAINT `Items-for-quote` FOREIGN KEY (`quote_no`) REFERENCES `quote` (`quote_no`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `items-for-order` FOREIGN KEY (`order_no`) REFERENCES `orders` (`order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `product-reference` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `quote`
--
ALTER TABLE `quote`
  ADD CONSTRAINT `quote-for-customer` FOREIGN KEY (`customer_id`) REFERENCES `client` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
