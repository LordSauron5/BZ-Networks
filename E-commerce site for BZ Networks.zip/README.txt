Before launching the system...
upload the sql script to your local DBMS

save the DB as bz_networksdb
do not set password on DB

login from the index.php file in the public folder

Below are some user login details for easy access:
 [User type : User name : password]
customer : barrybluebird: Jackie2
Admin : Belthezar: Admin#2020